<?php

namespace App\Http\Controllers;

class ClassificationController extends Controller
{
}
