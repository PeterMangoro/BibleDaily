<?php

namespace App\Http\Controllers;

class SocialController extends Controller
{
}
