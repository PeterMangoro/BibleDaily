<?php

namespace App\Http\Controllers;

class CategoryController extends Controller
{
}
