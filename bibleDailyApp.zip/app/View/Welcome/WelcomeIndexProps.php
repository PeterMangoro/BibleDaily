<?php

namespace App\View\Welcome;

use App\View\Shared\BaseView;

class WelcomeIndexProps extends BaseView
{
    // public function daily_verse()
    // {
    //     $bible = new Bible();

    //     // return
    // }
}
