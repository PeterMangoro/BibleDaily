<template>
    <p class="text-lg"> 📖 📝 </p>
</template>
