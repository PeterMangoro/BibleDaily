<template>
  <tr class="text-black">
    <slot />
  </tr>
</template>