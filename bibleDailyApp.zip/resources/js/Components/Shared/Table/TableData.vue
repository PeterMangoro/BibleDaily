<template>
  <td class="px-4 py-3 border-b"><slot /></td>
</template>